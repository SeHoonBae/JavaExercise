package com.test.example.constructor.constructorex;
/**
 * 
 * @author sehoon
 *
 */
public class Student {
/**
 * name = 학생이름
 */
	private String name;
/**
 * age = 학생나이
 */
	private int age;
	/**
	 * grade = 학생 학급
	 */
	private int grade;
	/**
	 * classNumber = 학생 반
	 */
	private int classNumber;
	/**
	 * number = 학생 번호
	 */
	private int number;
	/**
	 * school = 학생이 다니고 있는 학교
	 */
	private static String school;
	
	public Student() {
		this("미정",0,0,0,0);
	}
	
	public Student(String name, int age, int grade, int classNumber, int number) {
		this.name = name;
		this.age = age;
		this.grade = grade;
		this.classNumber = classNumber;
		this.number = number;
	}
	
	public Student(String name, int age) {
		this(name,age,0,0,0);
	}
	
	public Student(int grade, int classNumber, int number) {
		this("미정", 0, grade, classNumber, number);
	}
	
	static {
		school="역삼 중학교";
	}
	
	public String info() {
		
		String ageString = "";
		String gradeString = "";
		String classNumberString = "";
		String numberString = "";
		
		if(this.age == 0 ) {
			ageString = "미정";
		}else ageString = this.age + "";
		
		if(this.grade == 0 ) {
			gradeString = "미정";
		}else gradeString = grade + "";
		if(this.classNumber == 0 ) {
			classNumberString = "미정";
		}else classNumberString = classNumber + "";
		if(this.number == 0 ) {
			numberString = "미정";
		}else numberString = number + "";
		
		
		return this.name+"(나이 : " + ageString + ", 학년 : " + gradeString + ", 반 : "
				+ classNumberString + ", 번호 : " + numberString + ")";
	}
}
