package com.test.example.constructor.constructorex;

public class Time {

	private int hour;
	private int minute;
	private int second;

	public Time() throws Exception {
		this(0,0,0);
	}
	
	public Time(int hour, int minute, int second) throws Exception {
		if(hour >= 0 && minute >= 0 && second >= 0) {
			this.second = second % 60;
			this.minute = ( minute + second/60) % 60;
			this.hour = hour + ((minute + second/60)/60);
		}else throw new Exception();
	}
	
	public Time(int minute, int second) throws Exception {
		this(0,minute,second);
	}
	
	public Time(int second) throws Exception {
		this(0,0,second);
	}
	
	public String info() {
		return this.hour + ":" + this.minute + ":" + this.second;
	}
	
}
