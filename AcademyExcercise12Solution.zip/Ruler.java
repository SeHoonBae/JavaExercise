package static_class_ex1;

public class Ruler {

	private int length;
	private String shape;
	
	public int getLength() {
		return length;
	}
	
	public void setLength(int length) throws Exception {
		if(length == 30 || length == 50 || length == 100)
			this.length = length;
		else throw new Exception();
	}
	
	public String getShape() {
		return shape;
	}
	
	public void setShape(String shape) throws Exception {
		if(shape.equals("줄자") || shape.equals("운형자") || shape.equals("삼각자"))
			this.shape = shape;
		else throw new Exception();
	}
	
	public String info() {
		return "포장 전 검수 : " + this.getLength() + "cm " + this.getShape() + "입니다.";
	}
	
}
