package static_class_ex1;

public class Packer {

	private static int pencilCount;
	private static int eraserCount;
	private static int ballPointPenCount;
	private static int rulerCount;
	
	public static int getPencilCount() {
		return pencilCount;
	}
	
	public static int getEraserCount() {
		return eraserCount;
	}

	public static int getBallPointPenCount() {
		return ballPointPenCount;
	}
	
	public static int getRulerCount() {
		return rulerCount;
	}
	
	public void packing(Pencil pencil) {
		pencilCount++;
		System.out.println(pencil.info());
		System.out.println("포장을 완료했습니다.");
	}
	
	public void packing(Eraser eraser) {
		eraserCount++;
		System.out.println(eraser.info());
		System.out.println("포장을 완료했습니다.");
	}
	
	public void packing(BallPointPen ballPointPen) {
		ballPointPenCount++;
		System.out.println(ballPointPen.info());
		System.out.println("포장을 완료했습니다.");
	}
	
	public void packing(Ruler ruler) {
		rulerCount++;
		System.out.println(ruler.info());
		System.out.println("포장을 완료했습니다.");
	}
	
	public void countPacking(int type) throws Exception {
		if(type == 0 || type == 1 || type == 2 || type == 3 || type == 4) {
			if(type == 0) {
				System.out.println();
				System.out.println("================");
				System.out.println("포장 결과");
				System.out.println("================");
				System.out.printf("연필 %d회\n",Packer.pencilCount);
				System.out.printf("지우개 %d회\n",Packer.eraserCount);
				System.out.printf("볼펜 %d회\n",Packer.ballPointPenCount);
				System.out.printf("자 %d회\n",Packer.rulerCount);
			}
			else if(type == 1) {
				System.out.println();
				System.out.println("================");
				System.out.println("포장 결과");
				System.out.println("================");
				System.out.printf("연필 %d회\n",Packer.pencilCount);
			}
			else if( type == 2 ) {
				System.out.println();
				System.out.println("================");
				System.out.println("포장 결과");
				System.out.println("================");
				System.out.printf("지우개 %d회\n",Packer.eraserCount);
			}
			else if( type == 3 ) {
				System.out.println();
				System.out.println("================");
				System.out.println("포장 결과");
				System.out.println("================");
				System.out.printf("볼펜 %d회\n",Packer.ballPointPenCount);
			}
			else {
				System.out.println();
				System.out.println("================");
				System.out.println("포장 결과");
				System.out.println("================");
				System.out.printf("자 %d회\n",Packer.rulerCount);
			}
		}
		else throw new Exception();
	}
	
	
	
}
