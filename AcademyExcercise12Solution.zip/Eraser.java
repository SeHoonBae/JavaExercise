package static_class_ex1;

public class Eraser {

	private String size;

	public String getSize() {
		return size;
	}

	public void setSize(String size) throws Exception {
		if(size.equals("Large") || size.equals("Medium") || size.equals("Small"))
			this.size = size;
		else throw new Exception();
	}
	
	public String info() {
		return "포장 전 검수 : " + this.getSize() + " 사이즈 지우개입니다.";
	}
	
}
