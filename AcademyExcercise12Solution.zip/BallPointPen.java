package static_class_ex1;

public class BallPointPen {

	private double thickness;
	private String color;
	
	public double getThickness() {
		return thickness;
	}
	
	public void setThickness(double thickness) throws Exception {
		if(thickness==0.3 || thickness==0.5 || thickness==0.7 || thickness==1 || thickness==1.5)
			this.thickness = thickness;
		else throw new Exception();
	}
	
	public String getColor() {
		return color;
	}
	
	public void setColor(String color)throws Exception {
		if(color.equals("red") || color.equals("blue") || color.equals("green") || color.equals("black"))
			this.color = color;
		else throw new Exception();
	}
	
	public String info() {
		return "포장 전 검수 : " + this.getColor() + " 색상 " + getThickness()+ "mm " + "볼펜입니다.";
	}
	
}
