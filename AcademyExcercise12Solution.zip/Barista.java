package static_class_ex2;

public class Barista {

	
	public Espresso makeEspresso(int bean) {
		Espresso espresso = new Espresso();
		espresso.setBean(bean);
		
		Coffee.setBean(Coffee.getBean()+bean);
		Coffee.setEspresso(Coffee.getEspresso()+1);
		
		return espresso;
		
	}

	public Espresso[] makeEspressoes(int bean, int count) {
		Espresso[] espresso = new Espresso[count];
		
		for(int i=0; i<espresso.length; i++) {
			espresso[i]=new Espresso();
			espresso[i].setBean(bean);
			
			Coffee.setBean(Coffee.getBean()+bean);
			Coffee.setEspresso(Coffee.getEspresso()+1);
		}
		
		return espresso;
	}
	
	public Latte makeLatte(int bean, int milk) {
		
		Latte latte = new Latte();
		
		latte.setBean(bean);
		latte.setMilk(milk);
		
		Coffee.setBean(Coffee.getBean()+bean);
		Coffee.setMilk(Coffee.getMilk()+milk);
		Coffee.setLatte(Coffee.getLatte()+1);
		
		return latte;
	}
	
	public Latte[] makeLattes(int bean, int milk, int count) {
		Latte[] latte = new Latte[count];
		
		for(int i=0; i<latte.length; i++) {
			
			latte[i]=new Latte();
			latte[i].setBean(bean);
			latte[i].setMilk(milk);
			
			Coffee.setBean(Coffee.getBean()+bean);
			Coffee.setMilk(Coffee.getMilk()+milk);
			Coffee.setLatte(Coffee.getLatte()+1);
		}
		
		return latte;
	}
	
//	//바리스타
//	Barista barista = new Barista();
//
//	//손님 3
//	//아메리카노 1잔 주문 - 원두 30g, 물 300ml, 각얼음 20개
//	Americano a1 = barista.makeAmericano(30, 300, 20);
//	a1.drink();
//
//	//손님 4
//	//에스프레소 10잔 주문 - 원두 25g
//	Espresso[] e2 = barista.makeEspressoes(25, 10);
//
//	for (Espresso e : e2) {
//	    e.drink();
//	}
//
//	//손님 5
//	//라테 5잔 주문 - 원두 25g, 우유 300ml
//	Latte[] l2 = barista.makeLattes(25, 300, 5);
//
//	for (Latte l : l2) {
//	    l.drink();
//	}
//
//	//손님 6
//	//아메리카노 15잔 주문 - 원두 20g, 물 350ml, 각얼음 30개
//	Americano[] a2 = barista.makeAmericanos(20, 350, 30, 15);
//
//	for (Americano a : a2) {
//	    a.drink();
//	}
//
//	//결산
//	barista.result();
	
	public Americano makeAmericano(int bean, int water, int ice) {
		Americano americano =new Americano();
		
		americano.setBean(bean);
		americano.setWater(water);
		americano.setIce(ice);
		
		Coffee.setBean(Coffee.getBean()+bean);
		Coffee.setWater(Coffee.getWater()+water);
		Coffee.setIce(Coffee.getIce()+ice);
		
		Coffee.setAmericano(Coffee.getAmericano()+1);
		
		
		return americano;
	}
	
	public Americano[] makeAmericanos(int bean, int water, int ice, int count) {
		Americano[] americano = new Americano[count];
		
		for(int i=0; i<americano.length; i++) {
			americano[i]=new Americano();
			
			americano[i].setBean(bean);
			americano[i].setWater(water);
			americano[i].setIce(ice);
			
			Coffee.setBean(Coffee.getBean()+bean);
			Coffee.setWater(Coffee.getWater()+water);
			Coffee.setIce(Coffee.getIce()+ice);
			
			Coffee.setAmericano(Coffee.getAmericano()+1);
		}
		
		return americano;
	}
	
	public void result() {
		Coffee.setBeanTotalPrice(Coffee.getBean()*Coffee.getBeanUnitPrice());
		Coffee.setWaterTotalPrice((int)(Coffee.getWater()*Coffee.getWaterUnitPrice()));
		Coffee.setIceTotalPrice(Coffee.getIce()*Coffee.getIceUnitPrice());
		Coffee.setMilkTotalPrice(Coffee.getMilk()*Coffee.getMilkUnitPrice());
		
		System.out.println("==================================");
		System.out.println("판매 결과");
		System.out.println("==================================");
		System.out.println();
		
		System.out.println("----------------------------------");
		System.out.println("음료 판매량");
		System.out.println("----------------------------------");
		
		System.out.println("에스프레소 : "+Coffee.getEspresso()+"잔");
		System.out.println("아메리카노 : "+Coffee.getAmericano()+"잔");
		System.out.println("라테 : "+Coffee.getLatte()+"잔");
		System.out.println();
		System.out.println("----------------------------------");
		System.out.println("원자재 소비량");
		System.out.println("----------------------------------");
		System.out.printf("원두 : %,5dg\n",Coffee.getBean());
		System.out.printf("물 : %,5dml\n",Coffee.getWater());
		System.out.printf("얼음 : %,5d개\n",Coffee.getIce());
		System.out.printf("우유 : %,5dml\n",Coffee.getMilk());
		System.out.println();
		System.out.println("----------------------------------");
		System.out.println("매출액");
		System.out.println("----------------------------------");
		System.out.printf("원두 : %,5d원\n",Coffee.getBeanTotalPrice());
		System.out.printf("물 : %,5d원\n",Coffee.getWaterTotalPrice());
		System.out.printf("얼음 : %,5d원\n",Coffee.getIceTotalPrice());
		System.out.printf("우유 : %,5d원\n",Coffee.getMilkTotalPrice());
		
	}
	
}
